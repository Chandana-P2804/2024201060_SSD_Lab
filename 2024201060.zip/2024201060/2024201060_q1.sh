#!/bin/bash

#first get the lines that contain "POST" using grep and then filter on them for " 404" status code using grep again
grep  'POST' access.log | grep '404'
