This is 2024201060 first SSD Lab

The 1st qn script -->2024201060_q1.sh
..This script filters out the data present in access.log which contains both "POST" and "404" using "grep" command
..First the grep command filters the lines which contains "POST" and then again filters on the obtained data that contain "404"

The 2nd qn script -->2024201060_q2.sh
..This script sums up the values of last field in the file power_levels.txt and prints it using "awk" command
..The "$NF" is used to get values of last column, and -F',' ignores the delimeters between the columns
..add the values using sum += $NF ,which gives the sum of all values of last column and print them
