#!/bin/bash

# Ignore the delimeter using -F',' and sum up the 4th(last column) column
awk -F',' '{sum += $NF} END {print sum}' power_levels.txt